chrome.browserAction.onClicked.addListener(function(tab) {
	chrome.storage.local.get(['theme'], function(data) {
	  if (typeof data.theme === 'undefined') {
	    chrome.storage.local.set({"theme": "dark"});
	  } else {
	  	console.log(data.theme);
	  }
	});
	chrome.storage.local.get(['accent'], function(data) {
	  if (typeof data.accent === 'undefined') {
	    chrome.storage.local.set({"accent": "asylum"});
	  } else {
	  	console.log(data.accent);
	  }
	});
	var newURL = "./Pages/home.html";
	chrome.tabs.create({ url: newURL });
});