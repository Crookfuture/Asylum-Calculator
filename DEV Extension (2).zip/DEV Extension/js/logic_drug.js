/*
===================================================
This is the main Development file do not use this when uploading
to Extension package. This file should be closure compiled (Makes it unreadable)
then set to loaddrg-1.1.js in the plugin section
===================================================
*/
const itemLink = "https://api.myjson.com/bins/12qenq";
const inventoryLink = "https://api.myjson.com/bins/1fp9iy";
const totalCalc = "https://api.myjson.com/bins/ba33u";
const gperk = 0.10;
const cartelPercent = 0.2;
const formatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  minimumFractionDigits: 2
});

function ById (id) { 
  return document.getElementById(id); 
};

function gangPerk () {
    let gperk = 0;
    if (ById('dropdown-gangperk').value === "no") {gperk = 0;}
    if (ById('dropdown-gangperk').value === "1") {gperk = 0.05;}
    if (ById('dropdown-gangperk').value === "2") {gperk = 0.10;}
    return gperk;
};

function communityGoal () {
    let goal = 0;
    if (ById('dropdown-goals').value === "1") {goal = 0.05;};
    if (ById('dropdown-goals').value === "2") {goal = 0.10;};
    if (ById('dropdown-goals').value === "3") {goal = 0.15;};
    if (ById('dropdown-goals').value === "4") {goal = 0.20;};
    if (ById('dropdown-goals').value === "no") {goal = 0;};
    return goal;
};

function infamyPerkValue () {
    let mod = 0;
    if (ById('dropdown-infamyperk').value === "1") {mod= 0.07;};
    if (ById('dropdown-infamyperk').value === "2") {mod = 0.15;};
    if (ById('dropdown-infamyperk').value === "3") {mod = 0.25;};
    if (ById('dropdown-infamyperk').value === "no") {mod = 0;};
    return mod;
};

// when calculate is clicked
document.addEventListener('DOMContentLoaded', async function() {
  $.get(totalCalc, function(data, textStatus, jqXHR) {
    ById('totalCalculations').innerHTML = parseInt(data.number);
  });
  var calculate = ById('calculate');
  calculate.addEventListener('click', async function(drugType, cartel, gangPerk, infamyPerk, inputTotal, sell, sellSpace, outputInfamy, outputMoney, outputCartel, cartelTake, totalSpace,trunkSpace, backpackSpace) {
    if (ById('dropdown-drug').value === "select") {
      ById('dropdrug').style.borderColor = "red";
    } else {
      ById('dropdrug').removeAttribute("style")
    };
    await outputSpace (totalSpace, trunkSpace, backpackSpace);
    drugCalc(drugType, cartel, gangPerk, infamyPerk, inputTotal, sell, totalSpace, trunkSpace, backpackSpace);
    //This pulls how many calculations has been made then adds 1 everytime you calculate
    $.get(totalCalc, function(data, textStatus, jqXHR) {
      number = 1+parseInt(data.number)
      var json = {"number":number};
      var dataNew = JSON.stringify(json);
      $.ajax({
          url:totalCalc,
          type:"PUT",
          data:dataNew,
          contentType:"application/json; charset=utf-8",
          dataType:"json",
          success: function(data, textStatus, jqXHR){
            ById('totalCalculations').innerHTML = 1+parseInt(data.number);
          }
      });
    });
  });
});
// main logic
var Global = {};
async function drugCalc (drugType, cartel, gangPerk, infamyPerk, inputTotal, sell, sellSpace, totalSpace, trunkSpace, backpackSpace) {
  var cartel = ById('dropdown-cartel').value;
  var inputTotal = ById('input-total').value;
  var drugType = ById('dropdown-drug').value;
  var gangPerk = ById('dropdown-gangperk').value;
  var infamyPerk = ById('dropdown-infamyperk').value;
  if (drugType != "select") {
    await $.get(itemLink, function(data, textStatus, jqXHR) {
      drugSell = data.items[drugType].sellprice;
      return parseInt(drugSell);
    });
    await $.get(itemLink, function(data, textStatus, jqXHR) {
      drugWeight = data.items[drugType].weight;
      return parseInt(drugWeight);
    });
  } else {
    drugSell = 0;
    return drugSell;
    drugWeight = 0;
    return drugWeight;
  };
  async function output (sell, sellSpace, cartelTake, cartelTakeSpace) {
    var cartel = ById('dropdown-cartel').value;
    var outputInfamy = ById('outputinfamy');
    var outputMoney = ById('output');
    var outputCartel = ById('outputcartel');
    var outputInfamySpace = ById('outputinfamy-space');
    var outputMoneySpace = ById('output-space');
    var outputCartelSpace = ById('outputcartel-space');
    let infamy = sell/250;
    let infamySpace = sellSpace/250;
    outputMoney.innerHTML  = formatter.format(sell);
    outputMoneySpace.innerHTML  = formatter.format(sellSpace);
    outputInfamy.innerHTML = infamy.toFixed(2);
    outputInfamySpace.innerHTML = infamySpace.toFixed(2);
    if (cartel === "yes") {
      outputCartel.innerHTML = formatter.format(0);
      outputCartelSpace.innerHTML = formatter.format(0);       
    };
    if (cartel === "no") {
      outputCartel.innerHTML = formatter.format(cartelTake);
      outputCartelSpace.innerHTML = formatter.format(cartelTakeSpace);
    };
  };
  var infamyMod = 0;
  if (infamyPerk === "1") {infamyMod = 0.07;};
  if (infamyPerk === "2") {infamyMod = 0.15;};
  if (infamyPerk === "3") {infamyMod = 0.25;};
  if (infamyPerk === "no") {infamyMod = 0;};
  var sell = 0;
  var gPerkGain = (gperk*(drugSell*inputTotal));
  var infamyPerkGain = (infamyMod*(drugSell*inputTotal));
  var allGain = ((drugSell*inputTotal)+gPerkGain)+(infamyMod*((drugSell*inputTotal)+gPerkGain));
  var sellSpace = 0;
  var inputTotalSpace = (ById('outputdrug1').innerHTML);
  var gPerkGainSpace = (gperk*(drugSell*inputTotalSpace));
  var infamyPerkGainSpace = (infamyMod*(drugSell*inputTotalSpace));
  var allGainSpace = ((drugSell*inputTotalSpace)+gPerkGainSpace)+(infamyMod*((drugSell*inputTotalSpace)+gPerkGainSpace));
  if ((cartel === "yes") && (gangPerk === "yes")) {
    if ((infamyPerk === "1") || (infamyPerk === "2") || (infamyPerk === "3")) {
      sell = allGain;
      sellSpace = allGainSpace;
      output(sell, sellSpace);
    } else {
      sell = ((drugSell*inputTotal)+gPerkGain);
      sellSpace = ((drugSell*inputTotalSpace)+gPerkGainSpace);
      output(sell, sellSpace);
    };
  };
  if ((cartel === "yes") && (gangPerk === "no")) {
    if ((infamyPerk === "1") || (infamyPerk === "2") || (infamyPerk === "3")) {
      sell = ((drugSell*inputTotal)+infamyPerkGain);
      sellSpace = ((drugSell*inputTotalSpace)+infamyPerkGainSpace);
      output(sell, sellSpace);
    } else {
      sell = drugSell*inputTotal;
      sellSpace = drugSell*inputTotalSpace;
      output(sell, sellSpace);
    };
  };
  if ((cartel === "no") && (gangPerk === "yes")) {
    if ((infamyPerk === "1") || (infamyPerk === "2") || (infamyPerk === "3")) {
      cartelTake = allGain*cartelPercent;
      sell = allGain-cartelTake;
      cartelTakeSpace = allGainSpace*cartelPercent;
      sellSpace = allGainSpace-cartelTakeSpace;
      output(sell, sellSpace, cartelTake, cartelTakeSpace);
    } else {
      cartelTake = ((drugSell*inputTotal)+gPerkGain)*cartelPercent;
      sell = ((drugSell*inputTotal)+gPerkGain)-cartelTake
      cartelTakeSpace = ((drugSell*inputTotalSpace)+gPerkGainSpace)*cartelPercent;
      sellSpace = ((drugSell*inputTotalSpace)+gPerkGainSpace)-cartelTake
      output(sell, sellSpace, cartelTake, cartelTakeSpace);
    };
  };
  if ((cartel === "no") && (gangPerk === "no")) {
    if ((infamyPerk === "1") || (infamyPerk === "2") || (infamyPerk === "3")) {
      cartelTake = (((drugSell*inputTotal)+infamyPerkGain)*cartelPercent);
      sell = ((drugSell*inputTotal)+infamyPerkGain)-cartelTake;
      cartelTakeSpace = (((drugSell*inputTotalSpace)+infamyPerkGainSpace)*cartelPercent);
      sellSpace = ((drugSell*inputTotalSpace)+infamyPerkGainSpace)-cartelTakeSpace;
      output(sell, sellSpace, cartelTake, cartelTakeSpace);
    } else {
      cartelTake = (drugSell*inputTotal)*cartelPercent;
      sell = (drugSell*inputTotal)-cartelTake;

      cartelTakeSpace = (drugSell*inputTotalSpace)*cartelPercent;
      sellSpace = (drugSell*inputTotalSpace)-cartelTakeSpace;
      output(sell, sellSpace, cartelTake, cartelTakeSpace);
    };
  };
};

async function outputvideo () {
  var drugType = ById('dropdown-drug').value;
  if (drugType === "Meth") {
    ById('tutorial').src = "https://www.youtube.com/watch?v=0CW3RGhRrxk";
  };
  if (drugType === "Crank") {
    ById('tutorial').src = "https://www.youtube.com/watch?v=AQzLeJtRKRM";
  };
  if (drugType === "Heroin") {
    ById('tutorial').src = "https://www.youtube.com/watch?v=35f50bt35F4";
  };
  if (drugType === "Cocaine") {
    ById('tutorial').src = "https://www.youtube.com/watch?v=vxdwwOj8UhE";
  };
  if (drugType === "Weed") {
    ById('tutorial').src = "https://www.youtube.com/watch?v=LOFgpLX9rQA";
  };
};
// these functions below I need to shorten code and get values from myjson
async function outputDropdown () {
  var goalDrop = ById('dropdown-goals').value
  var goal = 0;
  if (goalDrop === "1") {goal = 0.05;};
  if (goalDrop === "2") {goal = 0.10;};
  if (goalDrop === "3") {goal = 0.15;};
  if (goalDrop === "4") {goal = 0.20;};
  if (goalDrop === "no") {goal = 0;};
  var vehicle = ById('dropdown-vehicle').value;
  var backpack = ById('dropdown-backpack').value;
  await $.get(inventoryLink, function(data, textStatus, jqXHR) {
    if (backpack === "select") {
      ById('backpackCount').innerHTML = 0;
    } else {
      ById('backpackCount').innerHTML = parseInt(data.backpack[backpack].inventory);
    };
    if (vehicle === "select") {
      ById('vehicleCount').innerHTML = 0;
    } else {
      ById('vehicleCount').innerHTML = (parseInt(data.cars[vehicle].inventory)+(parseInt(data.cars[vehicle].inventory)*goal)).toFixed(0);
    };
  });
};

async function outputSpace (totalSpace, trunkSpace, backpackSpace) {
  var vehicle = ById('dropdown-vehicle').value;
  var backpack = ById('dropdown-backpack').value;
  var customSpace = ById('input-space').value;
  var drugType = ById('dropdown-drug').value;
  var backpackSpace = 0;
  var trunkSpace = 0;
  async function findSpace () {
    await $.get(inventoryLink, function(data, textStatus, jqXHR) {
      if (backpack != "select") {
        backpackSpace = parseInt(data.backpack[backpack].inventory);
      };
      if (vehicle != "select") {
        trunkSpace = parseInt(data.cars[vehicle].inventory);
      };
    });
    var goalDrop = ById('dropdown-goals').value;
    var goal = 0;
    if (goalDrop === "1") {goal = 0.05;};
    if (goalDrop === "2") {goal = 0.10;};
    if (goalDrop === "3") {goal = 0.15;};
    if (goalDrop === "4") {goal = 0.20;};
    if (goalDrop === "no") {goal = 0;};
    //with community goals if they add it code is backpackSpace = (backpackSpace+(backpackSpace*goal)).toFixed(0);
    backpackSpace = (backpackSpace).toFixed(0);
    trunkSpace = (trunkSpace+(trunkSpace*goal)).toFixed(0);
    var drugType = ById('dropdown-drug').value;
    if (drugType != "select") {
      await $.get(itemLink, function(data, textStatus, jqXHR) {
        ingredients = data.items[drugType].ingredients;
        Global.totalSpace = parseFloat(trunkSpace)+parseFloat(backpackSpace)+parseFloat(customSpace);
        ById('totalCount').innerHTML = Global.totalSpace;
        ById('vehicleCount2').innerHTML = trunkSpace;
        ById('backpackCount2').innerHTML = backpackSpace;
        ById('labeldrugtype3').innerHTML = ById('labeldrugtype2').innerHTML = ById('labeldrugtype').innerHTML = drugType;
        ById('outputdrug1').innerHTML = ((Global.totalSpace/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0);
        ById('outputdrug2').innerHTML = ((trunkSpace/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0);
        ById('outputdrug3').innerHTML = ((backpackSpace/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0);
        ById('type3').src = ById('type2').src = ById('type1').src = "../images/"+data.items[drugType].image;
        if (ingredients[0] != undefined) {
          ById('ing3').src = ById('ing2').src = ById('ing1').src = "../images/"+data.items[ingredients[0]].image;
          ById('labelmat7').innerHTML = ById('labelmat4').innerHTML = ById('labelmat1').innerHTML = ingredients[0];
          ById('outputmat1').innerHTML = ((Global.totalSpace/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0);
          ById('outputmat4').innerHTML = ((trunkSpace/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0)
          ById('outputmat7').innerHTML = ((backpackSpace/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0)
        } else {
          ById('ing3').src = ById('ing2').src = ById('ing1').src = ById('labelmat7').innerHTML = ById('labelmat4').innerHTML = ById('labelmat1').innerHTML = ById('outputmat1').innerHTML = ById('outputmat4').innerHTML = ById('outputmat7').innerHTML = "";
        }
        if (ingredients[1] != undefined) {
          ById('ing6').src = ById('ing5').src = ById('ing4').src = "../images/"+data.items[ingredients[1]].image;
          ById('labelmat8').innerHTML = ById('labelmat5').innerHTML = ById('labelmat2').innerHTML = ingredients[1];
          ById('outputmat2').innerHTML = ((Global.totalSpace/(data.items[ingredients[1]].weight))/ingredients.length).toFixed(0);
          ById('outputmat5').innerHTML = ((trunkSpace/(data.items[ingredients[1]].weight))/ingredients.length).toFixed(0)
          ById('outputmat8').innerHTML = ((backpackSpace/(data.items[ingredients[1]].weight))/ingredients.length).toFixed(0)
        } else {
          ById('ing6').src = ById('ing5').src = ById('ing4').src = ById('labelmat8').innerHTML = ById('labelmat5').innerHTML = ById('labelmat2').innerHTML = ById('outputmat2').innerHTML = ById('outputmat5').innerHTML = ById('outputmat8').innerHTML = "";
        }
        if (ingredients[2] != undefined) {
          ById('ing9').src = ById('ing8').src = ById('ing7').src = "../images/"+data.items[ingredients[2]].image;
          ById('labelmat9').innerHTML = ById('labelmat6').innerHTML = ById('labelmat3').innerHTML = ingredients[2];
          ById('outputmat3').innerHTML = ((Global.totalSpace/(data.items[ingredients[2]].weight))/ingredients.length).toFixed(0);
          ById('outputmat6').innerHTML = ((trunkSpace/(data.items[ingredients[2]].weight))/ingredients.length).toFixed(0)
          ById('outputmat9').innerHTML = ((backpackSpace/(data.items[ingredients[2]].weight))/ingredients.length).toFixed(0)
        } else {
          ById('ing9').src = ById('ing8').src = ById('ing7').src = ById('labelmat9').innerHTML = ById('labelmat6').innerHTML = ById('labelmat3').innerHTML = ById('outputmat3').innerHTML = ById('outputmat6').innerHTML = ById('outputmat9').innerHTML = "";
        }
      });
    };
  };
  if (ById('dropdown-drug').value != "select") {
    await findSpace();
  };
};