/* (BELOW) URL TO MYJSON used in function getJson / function putJson / function postJson. Since we don't want to change the value to myJson we make it a const so it can't be modified after runtime*/
const myJson = "https://api.myjson.com/bins/12qenq";

function localJson () {
    $.getJSON ("../.JSON/itemData.json", function (data, textStatus, jqXHR, localjson) {
    document.getElementById('localJson').innerHTML = JSON.stringify(data, undefined, 8); /* We set the div with id="result" inner html to dataJson */
    });
};

/* (BELOW) Creating a function named getJson that runs our jQuery.get */
function getJson () {
    $.get (myJson, function(data, textStatus, jqXHR) {
    	if (data != undefined) {
    		console.log(`Successfully GET: DATA`);
    		document.getElementById('result').innerHTML = JSON.stringify(data, undefined, 8); /* We set the div with id="result" inner html to dataJson */
    	} else {
    		console.log("Returning Undefined. Something is wrong");
    	};
    });
};

function putLocalJson () {
    $.getJSON ("../.JSON/itemData.json", function (data, textStatus, jqXHR) {
    	$.ajax ({
    		url:myJson, /* myJson is defined on line 2 since it's in our global scope and not in a functio and it's defined before this function is ran it will get the value from there */
    		type:"PUT",
    		data:JSON.stringify(data), /* dataJson variable is defined in line 63 since it's not in the global scope we pass the parameter (dataJson, -, -) to this function and on line 66 to use the value */
    		contentType:"application/json; charset=utf-8",
    		dataType:"json",
    		/* (BELOW) this function runs if it successfully puts the data */
    		success: function (data, textStatus, jqXHR) {
    			console.log(`Successfully PUT: DATA to ${myJson}`);
    			document.getElementById('result').innerHTML = JSON.stringify(data, undefined, 8); /* We set the div with id="result" inner html to dataJson */
    		}
    	});
    });
};

function search (key) {
    $.getJSON ("../.JSON/itemData.json", function (data, textStatus, jqXHR) {
    	console.log(data.items[key]);
    	document.getElementById('searchlocaljson').innerHTML = JSON.stringify(data.items[key], undefined, 8);
    });
    $.get (myJson, function(data, textStatus, jqXHR) {
    	if (data != undefined) {
    		document.getElementById('searchmyjson').innerHTML = JSON.stringify(data.items[key], undefined, 8); /* We set the div with id="result" inner html to dataJson */
    	} else {
    		console.log("Returning Undefined. Something is wrong");
    	};
    });
};

/* (BELOW) waits for all elements on page to load without this getElementById wont work as the id wont exist and this is only ran once*/
document.addEventListener('DOMContentLoaded', async function() {
    //getJson(); /* Whenever it loads result will show current json */
    localJson();
    getJson();
    /* (BELOW) Runs whenever update button is clicked | update buttons id="update" */
    document.getElementById('update').addEventListener('click', async function() {
    	putLocalJson();
    });
    document.getElementById('search').addEventListener('click', async function() {
    	var key = document.getElementById('input-key').value;
    	search(key);
    });
});


/*
document.getElementById('create').addEventListener('click', async function() {
	var key = document.getElementById('input-key').value;
	var value = document.getElementById('input-value').value;
	var dataJson = JSON.stringify({[key]:value});
	getJson();
	await postJson(dataJson);
	getJson();
});
*/