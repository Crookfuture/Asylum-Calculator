/*
===================================================
This is the main Development file do not use this when uploading
to Extension package. This file should be closure compiled (Makes it unreadable)
then set to loadlqr-1.0.js in the plugin section
===================================================
*/

const itemLink = "https://api.myjson.com/bins/12qenq";
const inventoryLink = "https://api.myjson.com/bins/1fp9iy";
const totalCalc = "https://api.myjson.com/bins/ba33u";
const gperk = 0.10;
const cartelPercent = 0.07;
const barrelSpace = 200;
const formatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  minimumFractionDigits: 2
});

var Global = {};

function ById (id) { 
  return document.getElementById(id); 
};

function communityGoal () {
    let goal = 0;
    if (ById('dropdown-goals').value === "1") {goal = 0.05;};
    if (ById('dropdown-goals').value === "2") {goal = 0.10;};
    if (ById('dropdown-goals').value === "3") {goal = 0.15;};
    if (ById('dropdown-goals').value === "4") {goal = 0.20;};
    if (ById('dropdown-goals').value === "no") {goal = 0;};
    return goal;
};

function gangPerk () {
    let gperk = 0;
    if (ById('dropdown-gangperk').value === "no") {gperk = 0;}
    if (ById('dropdown-gangperk').value === "1") {gperk = 0.05;}
    if (ById('dropdown-gangperk').value === "2") {gperk = 0.10;}
    return gperk;
};

function infamyPerkValue () {
    let mod = 0;
    if (ById('dropdown-infamyperk').value === "1") {mod= 0.07;};
    if (ById('dropdown-infamyperk').value === "2") {mod = 0.15;};
    if (ById('dropdown-infamyperk').value === "3") {mod = 0.25;};
    if (ById('dropdown-infamyperk').value === "no") {mod = 0;};
    return mod;
};

document.addEventListener('DOMContentLoaded', async function() {
  $.get(totalCalc, function(data, textStatus, jqXHR) {
    ById('totalCalculations').innerHTML = parseInt(data.number);
  });
  ById('calculate').addEventListener('click', async function(liquorType, cartel, gangPerk, inputTotal, sell, sellSpace, outputInfamy, outputMoney, outputCartel, cartelTake, totalSpace, trunkSpace, backpackSpace) {
    if (ById('dropdown-liquor').value === "select") {
      ById('dropliquor').style.borderColor = "red";
    } else {
      ById('dropliquor').removeAttribute("style")
    };
    await outputSpace (totalSpace, trunkSpace, backpackSpace);
    liquorCalc(liquorType, cartel, gangPerk, inputTotal, sell, totalSpace, trunkSpace, backpackSpace);
    $.get(totalCalc, function(data, textStatus, jqXHR) {
      number = 1+parseInt(data.number)
      var json = {"number":number};
      var dataNew = JSON.stringify(json);
      $.ajax({
        url:totalCalc,
        type:"PUT",
        data:dataNew,
        contentType:"application/json; charset=utf-8",
        dataType:"json",
        success: function(data, textStatus, jqXHR){
          ById('totalCalculations').innerHTML = parseInt(data.number);
        }
      });
    });
  });
});

async function liquorCalc (liquorType, cartel, mod, gangPerk, inputTotal, sell, sellSpace, totalSpace, trunkSpace, backpackSpace) {
  var cartel = ById('dropdown-cartel').value;
  var inputTotal = ById('input-total').value;
  var liquorType = ById('dropdown-liquor').value;
  var gangPerk = ById('dropdown-gangperk').value;
  if (liquorType != "select") {
    await $.get(itemLink, function(data, textStatus, jqXHR) {
      liquorSell = data.items[liquorType].sellprice;
      return parseInt(liquorSell);
      liquorWeight = data.items[liquorType].weight;
      return parseInt(liquorWeight);
    });
    //await $.get(itemLink, function(data, textStatus, jqXHR) {
      //liquorWeight = data.items[liquorType].weight;
      //return parseInt(liquorWeight);
    //});
  } else {
    liquorSell = 0;
    return liquorSell;
    liquorWeight = 0;
    return liquorWeight;
  };
  var infamyMod = infamyPerkValue();
  var infamyPerk = ById('dropdown-infamyperk').value
  var sell = 0;
  var gPerkGain = (gperk*(liquorSell*inputTotal));
  var infamyPerkGain = (infamyMod*(liquorSell*inputTotal));
  var allGain = ((liquorSell*inputTotal)+gPerkGain)+(infamyMod*((liquorSell*inputTotal)+gPerkGain));
  var sellSpace = 0;
  var inputTotalSpace = (ById('outputliquor1').innerHTML);
  var gPerkGainSpace = (gperk*(liquorSell*inputTotalSpace));
  var infamyPerkGainSpace = (infamyMod*(liquorSell*inputTotalSpace));
  var allGainSpace = ((liquorSell*inputTotalSpace)+gPerkGainSpace)+(infamyMod*((liquorSell*inputTotalSpace)+gPerkGainSpace));
  var sellBarrel = 0;
  var inputTotalBarrel = (ById('outputliquor4').innerHTML);
  var gPerkGainBarrel = (gperk*(liquorSell*inputTotalBarrel));
  var infamyPerkGainBarrel = (infamyMod*(liquorSell*inputTotalBarrel));
  var allGainBarrel = ((liquorSell*inputTotalBarrel)+gPerkGainBarrel)+(infamyMod*((liquorSell*inputTotalBarrel)+gPerkGainBarrel));
  if ((cartel === "yes") && (gangPerk === "yes")) {
    if ((infamyPerk === "1") || (infamyPerk === "2") || (infamyPerk === "3")) {
      sell = allGain;
      sellSpace = allGainSpace;
      sellBarrel = (allGainBarrel);
      output(sell, sellSpace, sellBarrel);
    } else {
      sell = ((liquorSell*inputTotal)+gPerkGain);
      sellSpace = ((liquorSell*inputTotalSpace)+gPerkGainSpace);
      sellBarrel = ((liquorSell*inputTotalBarrel)+gPerkGainBarrel);
      output(sell, sellSpace, sellBarrel);
    };
  };
  if ((cartel === "yes") && (gangPerk === "no")) {
    if ((infamyPerk === "1") || (infamyPerk === "2") || (infamyPerk === "3")) {
      sell = ((liquorSell*inputTotal)+infamyPerkGain);
      sellSpace = ((liquorSell*inputTotalSpace)+infamyPerkGainSpace);
      sellBarrel = ((liquorSell*inputTotalBarrel)+infamyPerkGainBarrel);
      output(sell, sellSpace, sellBarrel);
    } else {
      sell = liquorSell*inputTotal;
      sellSpace = liquorSell*inputTotalSpace;
      sellBarrel = (liquorSell*inputTotalBarrel);
      output(sell, sellSpace, sellBarrel);
    };
  };
  if ((cartel === "no") && (gangPerk === "yes")) {
    if ((infamyPerk === "1") || (infamyPerk === "2") || (infamyPerk === "3")) {
      cartelTake = allGain*cartelPercent;
      sell = allGain-cartelTake;
      cartelTakeSpace = allGainSpace*cartelPercent;
      cartelTakeBarrel = allGainBarrel*cartelPercent;
      sellSpace = allGainSpace-cartelTakeSpace;
      sellBarrel = (allGainBarrel-cartelTakeBarrel);
      output(sell, sellSpace, sellBarrel, cartelTake, cartelTakeSpace, cartelTakeBarrel);
    } else {
      cartelTake = ((liquorSell*inputTotal)+gPerkGain)*cartelPercent;
      sell = ((liquorSell*inputTotal)+gPerkGain)-cartelTake;
      cartelTakeSpace = ((liquorSell*inputTotalSpace)+gPerkGainSpace)*cartelPercent;
      cartelTakeBarrel = ((liquorSell*inputTotalBarrel)+gPerkGainBarrel)*cartelPercent
      sellSpace = ((liquorSell*inputTotalSpace)+gPerkGainSpace)-cartelTake;
      sellBarrel = ((liquorSell*inputTotalBarrel)+gPerkGainBarrel)-cartelTake;
      output(sell, sellSpace, sellBarrel, cartelTake, cartelTakeSpace, cartelTakeBarrel);
    };
  };
  if ((cartel === "no") && (gangPerk === "no")) {
    if ((infamyPerk === "1") || (infamyPerk === "2") || (infamyPerk === "3")) {
      cartelTake = (((liquorSell*inputTotal)+infamyPerkGain)*cartelPercent);
      sell = ((liquorSell*inputTotal)+infamyPerkGain)-cartelTake;
      cartelTakeSpace = (((liquorSell*inputTotalSpace)+infamyPerkGainSpace)*cartelPercent);
      cartelTakeBarrel = (((liquorSell*inputTotalBarrel)+infamyPerkGainBarrel)*cartelPercent);
      sellSpace = ((liquorSell*inputTotalSpace)+infamyPerkGainSpace)-cartelTakeSpace;
      sellBarrel = ((liquorSell*inputTotalBarrel)+infamyPerkGainBarrel)-cartelTakeBarrel;
      output(sell, sellSpace, sellBarrel, cartelTake, cartelTakeSpace, cartelTakeBarrel);
    } else {
      cartelTake = (liquorSell*inputTotal)*cartelPercent;
      sell = (liquorSell*inputTotal)-cartelTake;
      cartelTakeSpace = (liquorSell*inputTotalSpace)*cartelPercent;
      cartelTakeBarrel = (liquorSell*inputTotalBarrel)*cartelPercent;
      sellSpace = (liquorSell*inputTotalSpace)-cartelTakeSpace;
      sellBarrel = (liquorSell*inputTotalBarrel)-cartelTakeBarrel;
      output(sell, sellSpace, sellBarrel, cartelTake, cartelTakeSpace, cartelTakeBarrel);
    };
  };
  async function output (sell, sellSpace, sellBarrel, cartelTake, cartelTakeSpace, cartelTakeBarrel) {
    let infamy = sell/250;
    let infamySpace = sellSpace/250;
    let infamyBarrel = sellBarrel/250;
    ById('output').innerHTML  = formatter.format(sell);
    ById('output-space').innerHTML  = formatter.format(sellSpace);
    ById('output-barrel').innerHTML  = formatter.format(sellBarrel);
    ById('outputinfamy').innerHTML = infamy.toFixed(2);
    ById('outputinfamy-space').innerHTML = infamySpace.toFixed(2);
    ById('outputinfamy-barrel').innerHTML = infamyBarrel.toFixed(2);
    if (ById('dropdown-cartel').value === "yes") {
      ById('outputcartel').innerHTML = formatter.format(0);
      ById('outputcartel-space').innerHTML = formatter.format(0);
      ById('outputcartel-barrel').innerHTML = formatter.format(0);       
    };
    if (ById('dropdown-cartel').value === "no") {
      ById('outputcartel').innerHTML = formatter.format(cartelTake);
      ById('outputcartel-space').innerHTML = formatter.format(cartelTakeSpace);
      ById('outputcartel-barrel').innerHTML = formatter.format(cartelTakeBarrel);
    };
  };
};

async function outputvideo () {
  var liquorType = ById('dropdown-liquor').value;
  if (liquorType === "New Make Scotch") {
    ById('tutorial').src = "https://www.youtube.com/embed/SkmHOkP5B-Q";
  };
  if (liquorType === "Scotch") {
    ById('tutorial').src = "https://www.youtube.com/embed/YbJOTdZBX1g";
  };
  if (liquorType === "Scotch 15 Year") {
    ById('tutorial').src = "https://www.youtube.com/embed/9bp1ehUoWTg?start=13";
  };
  if (liquorType === "Scotch 25 Year") {
    ById('tutorial').src = "https://www.youtube.com/embed/-50NdPawLVY";
  };
  if (liquorType === "Whiskey") {
    ById('tutorial').src = "https://www.youtube.com/embed/tgbNymZ7vqY";
  };
  if (liquorType === "Moonshine") {
    ById('tutorial').src = "https://www.youtube.com/embed/tgbNymZ7vqY";
  };
};

document.addEventListener ('input', async function () {
  var goal = communityGoal();
  var inputBarrel = ById('input-barrel').value;
  var formula = (inputBarrel*barrelSpace)+(goal*(inputBarrel*barrelSpace));
  ById('barrelCount').innerHTML = formula;
});

async function outputDropdown () {
  var goal = communityGoal();
  var vehicle = ById('dropdown-vehicle').value;
  var backpack = ById('dropdown-backpack').value;
  var inputBarrel = ById('input-barrel').value;
  await $.get(inventoryLink, function(data, textStatus, jqXHR) {
    if (backpack === "select") {
      ById('backpackCount').innerHTML = 0;
    } else {
      ById('backpackCount').innerHTML = parseInt(data.backpack[backpack].inventory);
    };
    if (vehicle === "select") {
      ById('vehicleCount').innerHTML = 0;
    } else {
      ById('vehicleCount').innerHTML = (parseInt(data.cars[vehicle].inventory)+(parseInt(data.cars[vehicle].inventory)*goal)).toFixed(0);
    };
    var formula = (inputBarrel*barrelSpace)+(goal*(inputBarrel*barrelSpace));
    ById('barrelCount').innerHTML = formula;
  });
};

async function outputSpace (totalSpace, trunkSpace, backpackSpace) {
  var vehicle = ById('dropdown-vehicle').value;
  var backpack = ById('dropdown-backpack').value;
  var customSpace = ById('input-space').value;
  var liquorType = ById('dropdown-liquor').value;
  var backpackSpace = 0;
  var trunkSpace = 0;
  var goalDrop = ById('dropdown-goals').value
  var goal = communityGoal(goal);
  var inputBarrel = ById('input-barrel').value;
  var formula = (inputBarrel*barrelSpace)+(goal*(inputBarrel*barrelSpace));
  ById('barrelCount1').innerHTML = ById('barrelCount').innerHTML = formula;
  async function findSpace () {
    await $.get(inventoryLink, function(data, textStatus, jqXHR) {
      if (backpack != "select") {
        backpackSpace = parseInt(data.backpack[backpack].inventory);
      };
      if (vehicle != "select") {
        trunkSpace = parseInt(data.cars[vehicle].inventory)
      };
    });
    var liquorType = ById('dropdown-liquor').value;
    if (liquorType != "select") {
      await $.get (itemLink, function (data, textStatus, jqXHR) {
        var liquorType = ById('dropdown-liquor').value;
        ById('output-age1').innerHTML = ById('output-age').innerHTML = data.items[liquorType].age;
        ingredients = data.items[liquorType].ingredients;
        var image = "../images/"+data.items[liquorType].image;
        Global.totalSpace = parseFloat(trunkSpace)+parseFloat(backpackSpace)+parseFloat(customSpace);
        ById('totalCount').innerHTML = Global.totalSpace;
        ById('vehicleCount2').innerHTML = trunkSpace;
        ById('backpackCount2').innerHTML = backpackSpace;
        ById('labelliquortype4').innerHTML = ById('labelliquortype3').innerHTML = ById('labelliquortype2').innerHTML = ById('labelliquortype').innerHTML = liquorType;
        ById('outputliquor1').innerHTML = ((Global.totalSpace/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0);
        ById('outputliquor2').innerHTML = ((trunkSpace/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0);
        ById('outputliquor3').innerHTML = ((backpackSpace/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0);
        ById('outputliquor4').innerHTML = ((formula/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0);
        ById('type4').src = ById('type3').src = ById('type2').src = ById('type1').src = image;
        if (ingredients[0] != undefined) {
          ById('ing4').src = ById('ing3').src = ById('ing2').src = ById('ing1').src = "../images/"+data.items[ingredients[0]].image;
          ById('labelmat10').innerHTML = ById('labelmat7').innerHTML = ById('labelmat4').innerHTML = ById('labelmat1').innerHTML = ingredients[0];
          ById('outputmat1').innerHTML = ((Global.totalSpace/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0);
          ById('outputmat4').innerHTML = ((trunkSpace/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0)
          ById('outputmat7').innerHTML = ((backpackSpace/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0)
          ById('outputmat10').innerHTML = ((formula/(data.items[ingredients[0]].weight))/ingredients.length).toFixed(0);
        } else {
            ById('ing4').src = ById('ing3').src = ById('ing2').src = ById('ing1').src = ById('labelmat10').innerHTML = ById('labelmat7').innerHTML = ById('labelmat4').innerHTML = ById('labelmat1').innerHTML = ById('outputmat1').innerHTML = ById('outputmat4').innerHTML = ById('outputmat7').innerHTML = ById('outputmat10').innerHTML = "";
        };
        if (ingredients[1] != undefined) {
          ById('ing8').src = ById('ing7').src = ById('ing6').src = ById('ing5').src = "../images/"+data.items[ingredients[1]].image;
          ById('labelmat11').innerHTML = ById('labelmat8').innerHTML = ById('labelmat5').innerHTML = ById('labelmat2').innerHTML = ingredients[1];
          ById('outputmat2').innerHTML = ((Global.totalSpace/(data.items[ingredients[1]].weight))/ingredients.length).toFixed(0);
          ById('outputmat5').innerHTML = ((trunkSpace/(data.items[ingredients[1]].weight))/ingredients.length).toFixed(0)
          ById('outputmat8').innerHTML = ((backpackSpace/(data.items[ingredients[1]].weight))/ingredients.length).toFixed(0)
          ById('outputmat11').innerHTML = ((formula/(data.items[ingredients[1]].weight))/ingredients.length).toFixed(0);
        } else {
            ById('ing8').src = ById('ing7').src = ById('ing6').src = ById('ing5').src = ById('labelmat11').innerHTML = ById('labelmat8').innerHTML = ById('labelmat5').innerHTML = ById('labelmat2').innerHTML = ById('outputmat2').innerHTML = ById('outputmat5').innerHTML = ById('outputmat8').innerHTML = ById('outputmat11').innerHTML = "";
        };
        if (ingredients[2] != undefined) {
          ById('ing12').src = ById('ing11').src = ById('ing10').src = ById('ing9').src = "../images/"+data.items[ingredients[2]].image;
          ById('labelmat12').innerHTML = ById('labelmat9').innerHTML = ById('labelmat6').innerHTML = ById('labelmat3').innerHTML = ingredients[2];
          ById('outputmat3').innerHTML = ((Global.totalSpace/(data.items[ingredients[2]].weight))/ingredients.length).toFixed(0);
          ById('outputmat6').innerHTML = ((trunkSpace/(data.items[ingredients[2]].weight))/ingredients.length).toFixed(0)
          ById('outputmat9').innerHTML = ((backpackSpace/(data.items[ingredients[2]].weight))/ingredients.length).toFixed(0)
          ById('outputmat12').innerHTML = ((formula/(data.items[ingredients[2]].weight))/ingredients.length).toFixed(0);
        } else {
            ById('ing12').src = ById('ing11').src = ById('ing10').src = ById('ing9').src = ById('labelmat12').innerHTML = ById('labelmat9').innerHTML = ById('labelmat6').innerHTML = ById('labelmat3').innerHTML = ById('outputmat3').innerHTML = ById('outputmat6').innerHTML = ById('outputmat9').innerHTML = ById('outputmat12').innerHTML = "";
        };
        if (ingredients[3] != undefined) {
          ById('ing16').src = ById('ing15').src = ById('ing14').src = ById('ing13').src = "../images/"+data.items[ingredients[3]].image;
          ById('labelmat16').innerHTML = ById('labelmat15').innerHTML = ById('labelmat14').innerHTML = ById('labelmat13').innerHTML = ingredients[3];
          ById('outputmat13').innerHTML = ((Global.totalSpace/(data.items[ingredients[3]].weight))/ingredients.length).toFixed(0);
          ById('outputmat14').innerHTML = ((trunkSpace/(data.items[ingredients[3]].weight))/ingredients.length).toFixed(0)
          ById('outputmat15').innerHTML = ((backpackSpace/(data.items[ingredients[3]].weight))/ingredients.length).toFixed(0)
          ById('outputmat16').innerHTML = ((formula/(data.items[ingredients[3]].weight))/ingredients.length).toFixed(0);
        } else {
            ById('ing16').src = ById('ing15').src = ById('ing14').src = ById('ing13').src = ById('labelmat16').innerHTML = ById('labelmat15').innerHTML = ById('labelmat14').innerHTML = ById('labelmat13').innerHTML = ById('outputmat13').innerHTML = ById('outputmat14').innerHTML = ById('outputmat15').innerHTML = ById('outputmat16').innerHTML = "";
        };
        if (liquorType === "Moonshine") {
          ById('outputliquor4').innerHTML = "Can't put in Barrels"
          ById('outputmat16').innerHTML = ById('outputmat12').innerHTML = ById('outputmat11').innerHTML = ById('outputmat10').innerHTML = "";
        };
      });
    };
  };
  if (ById('dropdown-liquor').value != "select") {
    await findSpace();
  };
};